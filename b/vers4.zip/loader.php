<?php
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
    header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  exit;
}

$JSON = json_decode(file_get_contents('php://input'), true);

  
  
$menuCommands = '[{"name": "menus"
   ,"version": "v1.0"
   ,"home" :    { "type" : "text" , "result" : "<h1>Home</h1> Information we display for home"}
   ,"contact" : { "type" : "text" , "result" : "<h2>Contact</h2> Information we display for contact"}
   ,"leesphp" : { "type" : "php"  , "result" : "testrun.php"}
   ,"htmlees" : { "type" : "htm"  , "result" : "https://www.php.net/manual/en/function.file-get-contents.php"}
   ,"test"    : { "type" : "htm"  , "result" : "test.htm"}
   ,"hallo"   : { "type" : "text" , "result" : "Nog bietjie <h2>text</h2> soos hallo world"}
}]';
$menuObj = json_decode($menuCommands);   //force an object



if ($JSON)  {
  if (array_key_exists('task',$JSON)) {
	header('Content-Type: application/json');
	handleRequest($JSON);  //inside here we will echo our answer, should never come back!
  }
} else {
	header('Content-Type: application/json');
	echo json_encode(['error'=>'no json send - ons werk net met json hier' ]);
	exit;
}


//--------------------------------------------------------------
// Hierdie funskie kyk watter "task" is gestuur, en prosesseer dit
//--------------------------------------------------------------
function handleRequest($data) {   
  if(isset($data['task'])) {
	  switch ($data['task']) {
	  case "laaiData":
	     $answer = myLaaiDataDinge($data);
         echo json_encode($answer,1);
	     return;
      default:
         $result = [ 'payload' => 'weet noggie waarvoor hierdie is nie?' . $data['task'] ];
         return $result;
       }      
  }
}

//---------------------------------------------------------------------------------
// Hierdie funksie myLaaiDataDinge - lees die menuClick, en laai iets ooreenkomstig
//----------------------------------------------------------------------------------
function myLaaiDataDinge($data) {
  if (!array_key_exists('menuClick',$data)) { 
      return  ['error' => 'We need a menuClick buddy!']; 
  }
  $menuClick = $data['menuClick'];
  $c = strtolower($menuClick);
  
  global $menuObj;
  if ($menuObj == null) {
      global $menuCommands;
      return  ['error' => 'We need a better, more json good menu buddy!', 'payload' => 'error in json : ' . $menuCommands . ' test in lint']; 
  }
  
  if (!is_object($menuObj[0]->$c)) {
    return  ['error' => 'We need a better, more defined menuClick buddy!', 'payload' => $c . ' not good']; 
  } else {
    $menuArr = $menuObj[0]->$c;
  }
  if ($menuArr->type == null) {
      return  ['error' => 'this menu obj does not have a type buddy!', 'payload' => 'oops ' . $c]; 
  }
  switch ($menuArr->type) {
  case 'text' : 
        $result = ['payload' =>  $menuArr->result ];
        return $result;
  case 'php' : 
        $result = [];
        ob_start();
        include($menuArr->result);
        $result['payload'] = ob_get_clean();  
        return $result;
  case 'htm':
  case 'html':
        $result['payload'] = file_get_contents($menuArr->result);
        return $result;
  default: 
       $result = ['payload' => 'weet noggie wat nie? - kennie vir ' . $menuClick  ];
       return $result;
  }

//Groot fout, ons het deurgeval, en geen result gekry nie...
  $result = ['errorcode' => 999
             ,'result' => 'error'
             ,'error' => json_encode($data)
             ,'desc' => 'some descrip'];
  return $result;          
}
?>