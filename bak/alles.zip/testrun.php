<?php

 echo "this is some data in the testrun.php file";
 echo "<b> jelkjhwerwe r</b>";
 
 ?>