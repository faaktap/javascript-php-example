<?php
if ($_SERVER['REQUEST_METHOD'] == 'OPTIONS') {
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_METHOD']))
    header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
  if (isset($_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']))
    header("Access-Control-Allow-Headers: {$_SERVER['HTTP_ACCESS_CONTROL_REQUEST_HEADERS']}");
  exit;
}

$JSON = json_decode(file_get_contents('php://input'), true);

  
  
$menuCommands = '[{"name": "menus"
   ,"version": "v1.0"
   ,"home" :    { "type" : "text", "result":"<h1>Home</h1> Information we display for home"}
   ,"contact" : { "type" : "text", "result" : "<h2>Contact</h2> Information we display for contact"}
   ,"leesphp" : { "type" : "php" , "file" : "testrun.php"}
   ,"htmlees" : { "type" : "htm" , "file" : "https://www.php.net/manual/en/function.file-get-contents.php"}
   ,"test"    : { "type" : "htm" , "file" : "test.htm"}
}]';




if ($JSON)  {
  if (array_key_exists('task',$JSON)) {
	header('Content-Type: application/json');
	handleRequest($JSON);  //inside here we will echo our answer, should never come back!
  }
} else {
	header('Content-Type: application/json');
	echo json_encode(['error'=>'no json send - ons werk net met json hier' ]);
	exit;
}


//--------------------------------------------------------------
// Hierdie funskie kyk watter "task" is gestuur, en prosesseer dit
//--------------------------------------------------------------
function handleRequest($data) {   
  if(isset($data['task'])) {
	  switch ($data['task']) {
	  case "laaiData":
	     $answer = myLaaiDataDinge($data);
         echo json_encode($answer,1);
	     return;
      default:
         $result = [ 'payload' => 'weet noggie waarvoor hierdie is nie?' . $data['task'] ];
         return $result;
       }      
  }
}

//---------------------------------------------------------------------------------
// Hierdie funksie myLaaiDataDinge - lees die menuClick, en laai iets ooreenkomstig
//----------------------------------------------------------------------------------
function myLaaiDataDinge($data) {
  if (!array_key_exists('menuClick',$data)) { 
      return  ['error' => 'We need a menuClick buddy!']; 
  }
  $menuClick = $data['menuClick'];
  
  global $menuCommands;

/*$menus = json_decode($menuCommands,true);   //true force an array
$c = strtolower($menuClick);
echo "stuff1 " . json_encode($menus,true);
echo $c . '  menus0hometype ' . $menus[0][$c]['type'];
$type = $menus[0][$c]['type'];
echo '<br>type = ' . $type . '<br><br>';
print_r ($menus);*/


$menuObj = json_decode($menuCommands);   //force an object
$c = strtolower($menuClick);
//echo $c . '  menuObj ' . $menuObj[0]->$c->type;
$menuArr = $menuObj[0]->$c;
//print_r ($menuArr);
//echo '<br><br>' . $c . '  menuObj ' . $menuObj[0]->$c;
  
  switch (strtolower($menuClick)) {
  case 'home' : 
        $result = ['payload' =>  $menuArr->result ];
        return $result;
  case 'contact' : 
        $result = ['payload' =>  $menuArr->result ];
        return $result;
  case 'leesphp':
        $result = [];
        ob_start();
        include('testrun.php');
        $result['payload'] = ob_get_clean();  
        return $result;
  case 'htmlees':
        $result['payload'] = file_get_contents($menuArr->file);
        return $result;
  case 'test':
        $result['payload'] = file_get_contents($menuArr->file);
        return $result;
        
  default: 
       $result = ['payload' => 'weet noggie wat nie? - kennie vir ' . $menuClick  ];
       return $result;
  }
  $result = ['errorcode' => 999
             ,'result' => 'error'
             ,'error' => json_encode($data)
             ,'desc' => 'some descrip'];
  return $result;          
}
?>