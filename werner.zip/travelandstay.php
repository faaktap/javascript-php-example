<div class="card bg-dark text-white">
    <img src="assets/img/travelandstay/travelandstay-header.jpg" class="card-img" alt="...">
    <div class="card-img-overlay">
        <div class="row h-100">
            <div class="col my-auto">
                <h3 class="card-title raleway text-center"><strong>TRAVEL AND STAY</strong></h3>
            </div>
        </div>
    </div>
</div>
<br><br>
<div class="container">
    <div class="row">
        <div class="col-12 text-center">
            <a href="https://www.flyairlink.com" target="_new"><img src="assets/img/travelandstay/airlink.png"></a>
            <p>There is only one choice for premium air travel throughout SADEC – Airlink.</p>
            <p>With a best in class on-time performance track record, a modern fleet of 60
                aircraft, and a customer centred track record of reliability – accept no
                compromises.</p>
        </div>
    </div>
</div>
<br>