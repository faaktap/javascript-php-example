<div class="container-fluid footer">
    <div class="row justify-content-center">
        <a href="https://sacoronavirus.co.za/" target="_new"><h2 class="text-center">View SA Corona Virus site</h2></a>
        <br>
        <hr>
    </div>
    <div class="row">
        <div class="col-12 text-center">
            <br>
            <a href="https://web.facebook.com/MichelangeloAwards" target="_new"><img src="assets/img/facebook-logo.svg" width="30px" height="auto"></a>
            <a href="https://www.instagram.com/michelangelo_awards_sa/" target="_new"><img src="assets/img/instagram-logo.svg" width="30px" height="auto"></a>
            <a href="https://maiwsa.co.za/#https://twitter.com/miwaawards?lang=en" target="_new"><img src="assets/img/twitter-logo.svg" width="30px" height="auto"></a>
            <a href="https://www.linkedin.com/in/michelangelo-international-wine-spirits-awards-59135397/" target="_new"><img src="assets/img/linkedin-logo.svg" width="30px" height="auto"></a>
        </div>
    </div>
    <div class="row">
        <div class="col-12 text-center">
            <br>
            <a href="https://bidvestlounge.co.za" target="_new"><img src="assets/img/bidvest-lounge-small-inverse.png"></a>
        </div>
    </div>
    <div class="row">
        <div class="col-12 text-center">
            <p>© 2019 Michelangelo International Wine & Spirits Awards. All Rights Reserved.</p>
        </div>
    </div>
    <div class="row">
        <div class="col-12 mb-2 text-center">
            <a href="enter.php">ENTER</a> | <a href="privacy.php">PRIVACY</a> | <a href="disclaimer.php">LEGAL DISCLAIMER</a> | <a href="contact.php">CONTACT US</a>
        </div>
    </div>
</div>