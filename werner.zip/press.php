<div class="container">
    <h1 class="text-center">SkyWays and Flamingo - Inflight Magazines</h1>
            <div id="demo" class="carousel slide carousel-dark" data-ride="carousel">
                <ul class="carousel-indicators">
                    <li data-target="#demo" data-slide-to="0" class="active"></li>
                    <li data-target="#demo" data-slide-to="1"></li>
                    <li data-target="#demo" data-slide-to="2"></li>
                    <li data-target="#demo" data-slide-to="3"></li>
                    <li data-target="#demo" data-slide-to="4"></li>
                    <li data-target="#demo" data-slide-to="5"></li>
                    <li data-target="#demo" data-slide-to="6"></li>
                    <li data-target="#demo" data-slide-to="7"></li>
                    <li data-target="#demo" data-slide-to="8"></li>
                    <li data-target="#demo" data-slide-to="9"></li>
                    <li data-target="#demo" data-slide-to="10"></li>
                    <li data-target="#demo" data-slide-to="11"></li>
                    <li data-target="#demo" data-slide-to="12"></li>
                    <li data-target="#demo" data-slide-to="13"></li>
                    <li data-target="#demo" data-slide-to="14"></li>
                    <li data-target="#demo" data-slide-to="15"></li>
                    <li data-target="#demo" data-slide-to="16"></li>
                    <li data-target="#demo" data-slide-to="17"></li>
                    <li data-target="#demo" data-slide-to="18"></li>
                    <li data-target="#demo" data-slide-to="19"></li>
                    <li data-target="#demo" data-slide-to="20"></li>
                </ul -->
                <div class="carousel-inner">
                    <div class="carousel-item active">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-1.jpg" alt="Slide 1">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-2.jpg" alt="Slide 2">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-3.jpg" alt="Slide 3">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-4.jpg" alt="Slide 4">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-5.jpg" alt="Slide 5">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-6.jpg" alt="Slide 6">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-7.jpg" alt="Slide 7">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-8.jpg" alt="Slide 8">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-9.jpg" alt="Slide 9">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-10.jpg" alt="Slide 10">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-11.jpg" alt="Slide 11">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-12.jpg" alt="Slide 12">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-13.jpg" alt="Slide 13">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-14.jpg" alt="Slide 14">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-15.jpg" alt="Slide 15">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-16.jpg" alt="Slide 16">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-17.jpg" alt="Slide 17">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-18.jpg" alt="Slide 18">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-19.jpg" alt="Slide 19">
                    </div>
                    <div class="carousel-item">
                    <img class="d-block w-100" src="assets/img/press/skyways/skyways-and-flamingo-july-2019-20.jpg" alt="Slide 20">
                    </div>
                </div>
                <a class="carousel-control-prev" href="#demo" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="false"></span>
                    <span class="sr-only">Previous</span>
                </a>
                <a class="carousel-control-next" href="#demo" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="false"></span>
                    <span class="sr-only">Next</span>
                </a>
            </div>
</div>
<br><br>